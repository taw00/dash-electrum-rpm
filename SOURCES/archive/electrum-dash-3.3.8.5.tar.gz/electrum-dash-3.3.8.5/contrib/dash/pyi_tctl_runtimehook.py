# -*- coding: utf-8 -*-
"""PyInstaller runtime hook for trezorctl"""
from sys import exit
