# Android Tor Proxy setup

On android use [Orbot](https://guardianproject.info/apps/orbot/) to
configure and use Tor Proxy. It can be installed:
* [Via Google Play](https://market.android.com/details?id=org.torproject.android)
* [Via F-Droid](https://guardianproject.info/fdroid/)
* [Via Direct Download from Guardian Project (.apk)](https://guardianproject.info/releases/orbot-latest.apk)
