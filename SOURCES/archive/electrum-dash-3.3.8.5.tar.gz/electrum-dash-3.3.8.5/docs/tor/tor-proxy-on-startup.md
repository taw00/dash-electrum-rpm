# Configuring Tor Proxy detection on wallet startup

## Linux/macOS/Windows

<img alt="Qt GUI Network pererences" src="tor-settings-qt.png">

## Android


<img alt="Kivy GUI Network pererences" src="tor-settings-kivy.png">
