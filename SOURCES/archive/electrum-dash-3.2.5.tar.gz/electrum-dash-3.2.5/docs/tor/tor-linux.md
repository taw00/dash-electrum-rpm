# Linux Tor Proxy setup

## Ubuntu/Debian/Linux Mint

```
sudo apt-get install tor

sudo service tor start
```

## Fedora/Red Hat

```
sudo yum install tor

sudo service tor start
```
