# Windows Tor Proxy setup

Starting from Dash-Electrum release 3.2.3 Tor Proxy installer
is included in Dash-Electrum setup.
