x11-hash-1.4.zip was acquired this way...

pip download 'git+https://github.com/akhavr/x11_hash@1.4#egg=x11_hash-1.4'

